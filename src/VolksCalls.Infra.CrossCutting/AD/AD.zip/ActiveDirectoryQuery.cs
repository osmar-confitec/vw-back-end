﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VolksCalls.Infra.CrossCutting.AD
{
   public class ActiveDirectoryQuery
    {

        public string SamAccountName { get; set; }

        public string DisplayName { get; set; }

    }
}
